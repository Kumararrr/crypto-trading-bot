"""
hedge_logic.strategy - PURE decision logic of a volatility-breakout strategy.

No network, no API keys, no files, no clock, no Telegram, no main loop: nothing in this module can place an
order. You give the engine a market Snapshot, it updates its State and returns a list of Actions (plain data).
Executing those Actions on an exchange is the job of a separate adapter, which is deliberately NOT part of this repo.

Strategy
  1. ATR spike (current 5m ATR > 1.5 x its median) and a tight spread -> arm a BUY-stop above and a SELL-stop below.
  2. The stop that triggers becomes the position, the other one is cancelled. SL = 2 x ATR (0.4%..1.2%), TP = 3R.
  3. At +1R the SL moves to a fee-covering lock level; the rest runs to TP or to the time limit.
  4. If both stops trigger (whipsaw) both legs are managed; when one leg stops, the other either runs or is closed.
Risk gates: cooldown, max cycles per day, daily loss limit, spread filter, time limit, emergency close on failure.
"""
from __future__ import annotations

import math
import statistics
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

SIDES = ("LONG", "SHORT")


@dataclass(frozen=True)
class Config:
    risk_per_trade_usdt: float = 1.0      # 1R
    sl_atr_mult: float = 2.0
    sl_min_pct: float = 0.004
    sl_max_pct: float = 0.012
    tp_rr: float = 3.0
    entry_offset_atr: float = 0.6
    offset_min_pct: float = 0.002
    offset_max_pct: float = 0.006
    pending_mins: int = 20
    lock_trigger_r: float = 1.0
    default_sl_pct: float = 0.005         # only for positions adopted after a restart
    default_tp_pct: float = 0.015
    time_limit_mins: int = 120
    atr_spike_mult: float = 1.5
    max_spread_pct: float = 0.0005
    fee_rate: float = 0.0005
    lock_buffer_pct: float = 0.0003
    lock_min_gap_pct: float = 0.0003
    cooldown_mins: int = 30
    max_cycles_per_day: int = 6
    daily_loss_limit_usdt: float = 3.0
    unravel_mode: str = "RUN"             # when one leg of a whipsaw stops: RUN (keep the other) | CLOSE


@dataclass(frozen=True)
class Filters:
    """exchange symbol rules (tick / step / minimums). The defaults are placeholders, load the real ones in your adapter."""
    tick: float = 0.01
    step: float = 0.01
    min_qty: float = 0.01
    min_notional: float = 5.0

    def rt(self, x: float) -> float:
        return round(round(x / self.tick) * self.tick, 8)

    def floor_q(self, x: float) -> float:
        return round(math.floor(x / self.step + 1e-9) * self.step, 8)

    def size_qty(self, cfg: Config, price: float, sl_pct: float) -> float:
        qty = max(self.floor_q(cfg.risk_per_trade_usdt / (price * sl_pct)), self.min_qty)
        if qty * price < self.min_notional * 1.1:
            qty = round(math.ceil(self.min_notional * 1.1 / price / self.step) * self.step, 8)
        return qty


@dataclass
class Position:
    entry: float
    amt: float


@dataclass
class Snapshot:
    now: float                                   # unix seconds, supplied by the caller
    price: Optional[float]
    spread_pct: Optional[float]
    atr: float                                   # ATR(14) of the last CLOSED 5m candle
    atr_median: float                            # median of the last 50 ATR values
    positions: Optional[Dict[str, Position]] = field(default_factory=dict)   # None = the position query failed


@dataclass
class Leg:
    entry: float
    qty: float
    sl: float
    tp: float
    locked: bool = False


@dataclass
class Cycle:
    mode: str
    phase: str                                   # PENDING | RUN | HEDGED
    start: float
    sl_pct: float
    tp_pct: float
    qty: float
    legs: Dict[str, Leg] = field(default_factory=dict)
    triggers: Tuple[float, float] = (0.0, 0.0)


@dataclass
class State:
    cycle: Optional[Cycle] = None
    pnl_today: float = 0.0
    cycles_today: int = 0
    day: Optional[str] = None
    last_close: float = 0.0
    note: str = ""


@dataclass
class Action:
    """kinds: CANCEL_ALL | PLACE_ENTRY_STOPS(price=buy trigger, price2=sell trigger, qty) | CANCEL_ENTRY_STOP(side)
    | PLACE_PROTECTION(side, price=SL, price2=TP, qty) | MOVE_STOP(side, price, qty) | CANCEL_LEG_ORDERS(side)
    | CLOSE_POSITION(side, qty) | END_CYCLE(text) | NOTIFY(text)"""
    kind: str
    side: Optional[str] = None
    price: Optional[float] = None
    price2: Optional[float] = None
    qty: Optional[float] = None
    text: str = ""


def atr_metrics(candles, period: int = 14) -> Tuple[float, float]:
    """candles = [(high, low, close), ...] of CLOSED candles. returns (current ATR, median of the last 50 ATRs)"""
    trs, prev = [], None
    for h, l, c in candles:
        trs.append(h - l if prev is None else max(h - l, abs(h - prev), abs(l - prev)))
        prev = c
    vals = [sum(trs[i - period + 1:i + 1]) / period for i in range(period - 1, len(trs))]
    return (vals[-1], statistics.median(vals[-50:])) if vals else (0.0, 0.0)


class Engine:
    def __init__(self, cfg: Config = Config(), filters: Filters = Filters()):
        self.cfg, self.f = cfg, filters

    # ---------------------------------------------------------------- helpers
    def plan(self, price: float, atr: float) -> Tuple[float, float, float]:
        """(sl_pct, tp_pct, entry offset pct) from the current volatility"""
        c, ap = self.cfg, atr / price
        sl = min(c.sl_max_pct, max(c.sl_min_pct, c.sl_atr_mult * ap))
        off = min(c.offset_max_pct, max(c.offset_min_pct, c.entry_offset_atr * ap))
        return sl, c.tp_rr * sl, off

    def levels(self, side: str, entry: float, sl_pct: float, tp_pct: float) -> Tuple[float, float]:
        if side == "LONG":
            return self.f.rt(entry * (1 - sl_pct)), self.f.rt(entry * (1 + tp_pct))
        return self.f.rt(entry * (1 + sl_pct)), self.f.rt(entry * (1 - tp_pct))

    def lock_level(self, side: str, entry: float) -> float:
        """SL price where a stop-out still pays both fees plus a small buffer"""
        fee, buf = self.cfg.fee_rate, self.cfg.lock_buffer_pct
        if side == "LONG":
            return self.f.rt(entry * (1 + fee) / (1 - fee) + entry * buf)
        return self.f.rt(entry * (1 - fee) / (1 + fee) - entry * buf)

    def can_open(self, st: State, now: float) -> Tuple[bool, str]:
        c = self.cfg
        day = time.strftime("%Y-%m-%d", time.gmtime(now))
        if day != st.day:
            st.day, st.pnl_today, st.cycles_today = day, 0.0, 0
        if now - st.last_close < c.cooldown_mins * 60:
            return False, f"cooldown {int(c.cooldown_mins * 60 - (now - st.last_close))}s"
        if st.pnl_today <= -c.daily_loss_limit_usdt:
            return False, f"daily loss limit ({st.pnl_today:+.2f})"
        if st.cycles_today >= c.max_cycles_per_day:
            return False, "max cycles today"
        return True, ""

    def record_pnl(self, st: State, net: float) -> None:
        """call after an END_CYCLE with the real net result of the cycle (from your fills)"""
        st.pnl_today += net

    @staticmethod
    def _end(st: State, now: float) -> None:
        st.cycle, st.last_close = None, now

    # ---------------------------------------------------------------- main entry points
    def step(self, st: State, snap: Snapshot) -> List[Action]:
        if snap.positions is None or snap.price is None:
            st.note = "no reliable data - doing nothing"
            return []
        if st.cycle is None and snap.positions:
            return self._adopt(st, snap)
        if st.cycle is not None:
            return self._manage(st, snap)
        return self._maybe_open(st, snap)

    def on_failure(self, st: State, action: Action, now: float) -> List[Action]:
        """your adapter reports an Action it could not execute; the engine answers with the safe follow-up actions"""
        cyc = st.cycle
        if action.kind == "PLACE_PROTECTION" and cyc:
            acts = [Action("CANCEL_ALL")] + [Action("CLOSE_POSITION", side=s, qty=leg.qty) for s, leg in cyc.legs.items()]
            acts.append(Action("END_CYCLE", text="emergency: SL/TP could not be placed"))
            self._end(st, now)
            return acts
        if action.kind == "PLACE_ENTRY_STOPS":
            st.cycles_today = max(0, st.cycles_today - 1)
            self._end(st, now)
            return [Action("CANCEL_ALL"), Action("NOTIFY", text="breakout orders failed - cycle dropped")]
        if action.kind == "MOVE_STOP" and cyc and action.side in cyc.legs:
            cyc.legs[action.side].locked = False        # old SL is still active, retry next step
        return []

    # ---------------------------------------------------------------- internals
    def _maybe_open(self, st: State, snap: Snapshot) -> List[Action]:
        ok, why = self.can_open(st, snap.now)
        ratio = snap.atr / snap.atr_median if snap.atr_median > 0 else 0.0
        st.note = why or f"ATR x{ratio:.2f}"
        if not ok or ratio <= self.cfg.atr_spike_mult:
            return []
        if snap.spread_pct is None or snap.spread_pct > self.cfg.max_spread_pct:
            st.note = "spike seen but spread unknown/too wide"
            return []
        sl, tp, off = self.plan(snap.price, snap.atr)
        qty = self.f.size_qty(self.cfg, snap.price, sl)
        buy, sell = self.f.rt(snap.price * (1 + off)), self.f.rt(snap.price * (1 - off))
        st.cycle = Cycle("BREAKOUT", "PENDING", snap.now, sl, tp, qty, triggers=(buy, sell))
        st.cycles_today += 1
        return [Action("CANCEL_ALL"), Action("PLACE_ENTRY_STOPS", price=buy, price2=sell, qty=qty),
                Action("NOTIFY", text=f"BREAKOUT ARMED qty {qty} buy-stop {buy} sell-stop {sell} SL {sl * 100:.2f}% TP {tp * 100:.2f}%")]

    def _protect(self, cyc: Cycle, pos: Dict[str, Position]) -> List[Action]:
        acts = []
        for side, p in pos.items():
            sl, tp = self.levels(side, p.entry, cyc.sl_pct, cyc.tp_pct)
            cyc.legs[side] = Leg(p.entry, p.amt, sl, tp)
            acts.append(Action("PLACE_PROTECTION", side=side, price=sl, price2=tp, qty=p.amt))
        return acts

    def _adopt(self, st: State, snap: Snapshot) -> List[Action]:
        c = self.cfg
        cyc = Cycle("ADOPTED", "HEDGED" if len(snap.positions) == 2 else "RUN", snap.now, c.default_sl_pct, c.default_tp_pct, 0.0)
        acts = [Action("CANCEL_ALL")] + self._protect(cyc, snap.positions)
        st.cycle = cyc
        return acts + [Action("NOTIFY", text=f"positions adopted: {list(snap.positions)} - SL/TP re-placed, timer restarted")]

    def _manage(self, st: State, snap: Snapshot) -> List[Action]:
        cyc, pos, now = st.cycle, snap.positions, snap.now
        if cyc.phase == "PENDING":
            return self._pending(st, snap)
        if now - cyc.start > self.cfg.time_limit_mins * 60:
            acts = [Action("CANCEL_ALL")] + [Action("CLOSE_POSITION", side=s, qty=p.amt) for s, p in pos.items()]
            acts.append(Action("END_CYCLE", text=f"time limit {self.cfg.time_limit_mins} min"))
            self._end(st, now)
            return acts
        if not pos:
            self._end(st, now)
            return [Action("END_CYCLE", text="all legs closed (SL/TP)")]
        if cyc.phase == "HEDGED" and len(pos) == 1:
            return self._first_leg_closed(st, next(iter(pos)), snap)
        acts: List[Action] = []
        if cyc.phase == "RUN":
            for side, p in pos.items():
                acts += self._maybe_lock(cyc, side, p, snap.price)
        return acts

    def _pending(self, st: State, snap: Snapshot) -> List[Action]:
        cyc, pos = st.cycle, snap.positions
        if not pos:
            if snap.now - cyc.start > self.cfg.pending_mins * 60:
                st.cycles_today = max(0, st.cycles_today - 1)
                self._end(st, snap.now)
                return [Action("CANCEL_ALL"), Action("NOTIFY", text="no breakout - stops cancelled (no cost)")]
            return []
        acts = [Action("CANCEL_ENTRY_STOP", side=s) for s in SIDES if s not in pos]
        acts += self._protect(cyc, pos)
        cyc.phase, cyc.start = ("HEDGED" if len(pos) == 2 else "RUN"), snap.now
        what = "WHIPSAW: both stops triggered" if len(pos) == 2 else f"BREAKOUT {next(iter(pos))}"
        return acts + [Action("NOTIFY", text=what)]

    def _first_leg_closed(self, st: State, survivor: str, snap: Snapshot) -> List[Action]:
        cyc, p = st.cycle, snap.positions[survivor]
        dead = "SHORT" if survivor == "LONG" else "LONG"
        acts = [Action("CANCEL_LEG_ORDERS", side=dead)]
        if self.cfg.unravel_mode == "CLOSE":
            acts += [Action("CLOSE_POSITION", side=survivor, qty=p.amt), Action("END_CYCLE", text=f"{dead} stopped, {survivor} closed")]
            self._end(st, snap.now)
            return acts
        cyc.phase = "RUN"
        return acts + [Action("NOTIFY", text=f"{dead} leg stopped - {survivor} keeps running")] + self._maybe_lock(cyc, survivor, p, snap.price)

    def _maybe_lock(self, cyc: Cycle, side: str, p: Position, price: float) -> List[Action]:
        leg = cyc.legs.get(side)
        if not leg or leg.locked:
            return []
        r = p.entry * cyc.sl_pct * self.cfg.lock_trigger_r
        reached = price >= p.entry + r if side == "LONG" else price <= p.entry - r
        lock, gap = self.lock_level(side, p.entry), price * self.cfg.lock_min_gap_pct
        valid = lock < price - gap if side == "LONG" else lock > price + gap
        if not (reached and valid):
            return []
        leg.locked, leg.sl = True, lock
        return [Action("MOVE_STOP", side=side, price=lock, qty=p.amt),
                Action("NOTIFY", text=f"PROFIT LOCK {side}: SL moved to {lock} (fees covered)")]
