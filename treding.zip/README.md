# hedge-strategy-logic

Pure decision logic of a volatility-breakout strategy for crypto futures. **No exchange code, no API keys, no
network, no main loop** - nothing in this repository can place an order. It is meant for study, review and
back-testing; trading it is a separate, private decision.

> Educational code, not financial advice. Futures trading can lose more than you expect. No warranty.

## How it works
`Engine.step(state, snapshot)` takes a market snapshot (price, spread, ATR, open positions) and returns a list of
`Action` objects (data only). Your own adapter - which is *not* in this repo - would execute them and report failures
with `Engine.on_failure(...)`.

1. **Entry:** 5m ATR spike (> 1.5 x median) and spread <= 0.05% -> arm a BUY-stop above and a SELL-stop below the price.
2. **Fill:** the stop that triggers becomes the position, the other is cancelled. SL = 2 x ATR (0.4%-1.2%), TP = 3R,
   size = risk / SL distance (1R = 1 USDT by default).
3. **Profit lock:** at +1R the SL moves to a level that still pays both fees plus a small buffer.
4. **Whipsaw:** if both stops trigger, both legs are protected; when one stops the other keeps running (or is closed).
5. **Gates:** cooldown, max cycles/day, daily loss limit, spread filter, time limit, emergency close if SL/TP fails.

| Action | meaning for the adapter |
|---|---|
| `CANCEL_ALL` | cancel every open order of the symbol |
| `PLACE_ENTRY_STOPS` | buy-stop at `price`, sell-stop at `price2`, quantity `qty` |
| `CANCEL_ENTRY_STOP` / `CANCEL_LEG_ORDERS` | cancel the entry stop / the leftover SL+TP of `side` |
| `PLACE_PROTECTION` | stop-loss at `price` and take-profit at `price2` for `side`, `qty` |
| `MOVE_STOP` | place the new stop first, cancel the old one after it is accepted |
| `CLOSE_POSITION` | market-close `qty` of `side` |
| `END_CYCLE` | the cycle is over: read the real net result from your fills and call `Engine.record_pnl` |
| `NOTIFY` | informational text |

## Run the tests and the dry run
```
python -m unittest discover -s tests -v
python -m examples.dry_run
```

## Layout
```
hedge_logic/strategy.py   the whole strategy (standard library only)
tests/test_strategy.py    offline tests of every rule
examples/dry_run.py       scripted walk-through, prints the actions
```

## Before you push anything to GitHub
* never commit `.env`, API keys, bot tokens or log files (`.gitignore` already blocks the common ones);
* a key that was ever committed stays in the git history - revoke it, do not just delete the file;
* keep your exchange adapter and credentials in a separate **private** repository.
