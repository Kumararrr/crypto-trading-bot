import unittest

from hedge_logic import Action, Config, Engine, Filters, Position, Snapshot, State, atr_metrics

T0 = 1_800_000_000.0


def snap(now=T0, price=100.0, spread=0.0002, atr=0.3, med=0.15, positions=None):
    return Snapshot(now=now, price=price, spread_pct=spread, atr=atr, atr_median=med,
                    positions={} if positions is None else positions)


def kinds(acts):
    return [a.kind for a in acts]


def armed(eng=None, st=None):
    eng, st = eng or Engine(), st or State()
    acts = eng.step(st, snap())
    assert kinds(acts) == ["CANCEL_ALL", "PLACE_ENTRY_STOPS", "NOTIFY"], acts
    return eng, st, acts


class Tests(unittest.TestCase):
    def test_plan_clamps(self):
        e = Engine()
        self.assertEqual(e.plan(100, 0.05)[0], 0.004)                       # tiny ATR -> min SL
        self.assertEqual(e.plan(100, 2.0)[0], 0.012)                        # huge ATR -> max SL
        sl, tp, off = e.plan(100, 0.3)
        self.assertAlmostEqual(sl, 0.006); self.assertAlmostEqual(tp, 0.018); self.assertAlmostEqual(off, 0.002)

    def test_sizing_and_min_notional(self):
        e = Engine()
        self.assertAlmostEqual(e.f.size_qty(e.cfg, 100, 0.006), 1.66)
        tiny = Engine(Config(risk_per_trade_usdt=0.01))
        self.assertGreaterEqual(tiny.f.size_qty(tiny.cfg, 100, 0.006) * 100, 5.0)

    def test_lock_level_pays_the_fees(self):
        e = Engine()
        for side, entry in (("LONG", 100.25), ("SHORT", 100.25)):
            lock = e.lock_level(side, entry)
            gross = (lock - entry) if side == "LONG" else (entry - lock)
            fees = e.cfg.fee_rate * (entry + lock)
            self.assertGreater(gross - fees, 0, side)

    def test_arms_breakout(self):
        _, st, acts = armed()
        a = acts[1]
        self.assertEqual((a.price, a.price2, a.qty), (100.2, 99.8, 1.66))
        self.assertEqual(st.cycle.phase, "PENDING")
        self.assertEqual(st.cycles_today, 1)

    def test_entry_gates(self):
        e = Engine()
        self.assertEqual(e.step(State(), snap(atr=0.15)), [])                       # no spike
        self.assertEqual(e.step(State(), snap(spread=0.002)), [])                   # wide spread
        self.assertEqual(e.step(State(), snap(spread=None)), [])                    # unknown spread
        self.assertEqual(e.step(State(), Snapshot(T0, 100, 0.0002, 0.3, 0.15, None)), [])   # position query failed
        self.assertEqual(e.step(State(last_close=T0 - 60), snap()), [])             # cooldown
        self.assertEqual(e.step(State(day=None, pnl_today=0), snap()) != [], True)
        st = State(); e.can_open(st, T0); st.pnl_today = -3.0
        self.assertEqual(e.step(st, snap()), [])                                    # daily loss limit
        st = State(); e.can_open(st, T0); st.cycles_today = 6
        self.assertEqual(e.step(st, snap()), [])                                    # max cycles

    def test_new_day_resets_counters(self):
        e, st = Engine(), State(day="1999-01-01", pnl_today=-99.0, cycles_today=99)
        self.assertTrue(e.can_open(st, T0)[0])
        self.assertEqual((st.pnl_today, st.cycles_today), (0.0, 0))

    def test_pending_times_out_without_cost(self):
        e, st, _ = armed()
        self.assertEqual(e.step(st, snap(now=T0 + 600)), [])
        acts = e.step(st, snap(now=T0 + 21 * 60))
        self.assertEqual(kinds(acts), ["CANCEL_ALL", "NOTIFY"])
        self.assertIsNone(st.cycle); self.assertEqual(st.cycles_today, 0)

    def test_long_breakout_is_protected_and_other_stop_cancelled(self):
        e, st, _ = armed()
        acts = e.step(st, snap(now=T0 + 120, price=100.25, atr=0.3, positions={"LONG": Position(100.25, 1.66)}))
        self.assertEqual(kinds(acts), ["CANCEL_ENTRY_STOP", "PLACE_PROTECTION", "NOTIFY"])
        self.assertEqual(acts[0].side, "SHORT")
        prot = acts[1]
        self.assertEqual((prot.side, prot.price, prot.price2, prot.qty), ("LONG", 99.65, 102.05, 1.66))
        self.assertEqual(st.cycle.phase, "RUN")

    def test_profit_lock_at_plus_1r_once_and_retry_after_failure(self):
        e, st, _ = armed()
        pos = {"LONG": Position(100.25, 1.66)}
        e.step(st, snap(now=T0 + 120, price=100.25, positions=pos))
        self.assertEqual(e.step(st, snap(now=T0 + 130, price=100.5, positions=pos)), [])        # below +1R
        acts = e.step(st, snap(now=T0 + 140, price=100.9, positions=pos))                       # above +1R (100.8515)
        self.assertEqual(kinds(acts), ["MOVE_STOP", "NOTIFY"]); self.assertEqual(acts[0].price, 100.38)
        self.assertEqual(e.step(st, snap(now=T0 + 150, price=101.0, positions=pos)), [])        # only once
        e.on_failure(st, acts[0], T0 + 150)                                                     # exchange rejected it
        self.assertEqual(kinds(e.step(st, snap(now=T0 + 160, price=101.0, positions=pos))), ["MOVE_STOP", "NOTIFY"])

    def test_whipsaw_both_legs_then_first_leg_closes(self):
        for mode, expect in (("RUN", ["CANCEL_LEG_ORDERS", "NOTIFY"]), ("CLOSE", ["CANCEL_LEG_ORDERS", "CLOSE_POSITION", "END_CYCLE"])):
            e = Engine(Config(unravel_mode=mode)); st = State()
            armed(e, st)
            both = {"LONG": Position(100.2, 1.66), "SHORT": Position(99.8, 1.66)}
            acts = e.step(st, snap(now=T0 + 60, positions=both))
            self.assertEqual(kinds(acts), ["PLACE_PROTECTION", "PLACE_PROTECTION", "NOTIFY"]); self.assertEqual(st.cycle.phase, "HEDGED")
            acts = e.step(st, snap(now=T0 + 120, price=100.0, positions={"LONG": Position(100.2, 1.66)}))
            self.assertEqual(kinds(acts), expect, mode)
            self.assertEqual(acts[0].side, "SHORT")

    def test_time_limit_closes_everything(self):
        e, st, _ = armed()
        pos = {"LONG": Position(100.25, 1.66)}
        e.step(st, snap(now=T0 + 120, price=100.25, positions=pos))
        acts = e.step(st, snap(now=T0 + 120 + 121 * 60, price=100.3, positions=pos))
        self.assertEqual(kinds(acts), ["CANCEL_ALL", "CLOSE_POSITION", "END_CYCLE"])
        self.assertIsNone(st.cycle); self.assertEqual(st.last_close, T0 + 120 + 121 * 60)

    def test_cycle_end_starts_cooldown(self):
        e, st, _ = armed()
        pos = {"SHORT": Position(99.75, 1.66)}
        e.step(st, snap(now=T0 + 90, price=99.75, positions=pos))
        acts = e.step(st, snap(now=T0 + 300, positions={}))
        self.assertEqual(kinds(acts), ["END_CYCLE"]); self.assertIsNone(st.cycle)
        e.record_pnl(st, -1.2); self.assertAlmostEqual(st.pnl_today, -1.2)
        self.assertEqual(e.step(st, snap(now=T0 + 400)), [])                                   # cooldown

    def test_failure_paths_are_safe(self):
        e, st, acts = armed()
        out = e.on_failure(st, acts[1], T0 + 5)                                                 # entry stops rejected
        self.assertEqual(kinds(out), ["CANCEL_ALL", "NOTIFY"]); self.assertIsNone(st.cycle); self.assertEqual(st.cycles_today, 0)
        e, st, _ = armed()
        both = {"LONG": Position(100.2, 1.66), "SHORT": Position(99.8, 1.66)}
        prot = e.step(st, snap(now=T0 + 60, positions=both))[0]
        out = e.on_failure(st, prot, T0 + 61)                                                   # SL/TP rejected
        self.assertEqual(kinds(out), ["CANCEL_ALL", "CLOSE_POSITION", "CLOSE_POSITION", "END_CYCLE"]); self.assertIsNone(st.cycle)

    def test_restart_adopts_positions(self):
        e, st = Engine(), State()
        acts = e.step(st, snap(positions={"LONG": Position(100.0, 2.0)}))
        self.assertEqual(kinds(acts), ["CANCEL_ALL", "PLACE_PROTECTION", "NOTIFY"])
        self.assertEqual(st.cycle.mode, "ADOPTED"); self.assertEqual(st.cycle.phase, "RUN")

    def test_atr_metrics_detect_a_spike(self):
        calm = [(100.1, 99.9, 100.0)] * 80
        spike = [(100.6, 99.4, 100.0)] * 8
        cur, med = atr_metrics(calm + spike)
        self.assertGreater(cur / med, 1.5)
        self.assertEqual(atr_metrics([(1, 1, 1)] * 5), (0.0, 0.0))


if __name__ == "__main__":
    unittest.main()
