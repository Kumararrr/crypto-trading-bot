"""Feeds a scripted market to the engine and prints the Actions it would ask an adapter to execute. Nothing is sent anywhere."""
from hedge_logic import Engine, Position, Snapshot, State

T0 = 1_800_000_000.0
eng, st = Engine(), State()


def show(title, **kw):
    s = Snapshot(now=T0 + kw.pop("t"), price=kw.pop("price"), spread_pct=0.0002, atr=kw.pop("atr", 0.3), atr_median=0.15,
                 positions=kw.pop("positions", {}))
    print(f"\n--- {title} (price {s.price})")
    for a in eng.step(st, s):
        print("   ", a)


show("volatility spike", t=0, price=100.0)
show("buy-stop triggers", t=90, price=100.25, positions={"LONG": Position(100.25, 1.66)})
show("price reaches +1R", t=300, price=100.9, positions={"LONG": Position(100.25, 1.66)})
show("take profit hit", t=900, price=102.1, positions={})
print("\nstate after the cycle:", st)
